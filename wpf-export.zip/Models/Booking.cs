using System;

namespace QLSANCL.BadmintonManagement.Models
{
    public class Booking
    {
        public string Id { get; set; }
        public string Customer { get; set; }
        public string Phone { get; set; }
        public string Court { get; set; }
        public DateTime Date { get; set; }
        public string Time { get; set; }
        public string Type { get; set; } // Casual, Fixed
        public string Status { get; set; } // Pending, Checked-in, Cancelled
        public decimal Amount { get; set; }
    }
}
