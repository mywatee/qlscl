namespace QLSANCL.BadmintonManagement.Models
{
    public class Court
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; } // Indoor, Outdoor, Pro Mat
        public string Status { get; set; } // Available, In-use, Maintenance
    }
}
