using System;

namespace QLSANCL.BadmintonManagement.Models
{
    public class Customer
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public int TotalBookings { get; set; }
        public decimal TotalSpent { get; set; }
        public DateTime MemberSince { get; set; }
        public string Status { get; set; } // VIP, Regular, New
    }
}
