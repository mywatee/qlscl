namespace QLSANCL.BadmintonManagement.Models
{
    public class Service
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int Stock { get; set; }
        public string Category { get; set; } // Drinks, Equipment
    }

    public class CartItem
    {
        public Service Service { get; set; }
        public int Quantity { get; set; }
        public decimal Total => Service.Price * Quantity;
    }
}
