using System;

namespace QLSANCL.BadmintonManagement.Models
{
    public class Staff
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }
        public string Department { get; set; }
        public string Status { get; set; } // Active, On Leave, Inactive
        public DateTime JoinDate { get; set; }
    }
}
