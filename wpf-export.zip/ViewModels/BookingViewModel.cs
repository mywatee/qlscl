using System;
using System.Collections.ObjectModel;
using QLSANCL.BadmintonManagement.Models;

namespace QLSANCL.BadmintonManagement.ViewModels
{
    public class BookingViewModel : BaseViewModel
    {
        public ObservableCollection<Booking> Bookings { get; set; }
        public ObservableCollection<Court> Courts { get; set; }

        private string _searchText;
        public string SearchText
        {
            get => _searchText;
            set => SetProperty(ref _searchText, value);
        }

        public BookingViewModel()
        {
            LoadData();
        }

        private void LoadData()
        {
            Courts = new ObservableCollection<Court>
            {
                new Court { Id = 1, Name = "Court 1", Type = "Indoor" },
                new Court { Id = 2, Name = "Court 2", Type = "Indoor" },
                new Court { Id = 3, Name = "Court 3", Type = "Indoor" },
                new Court { Id = 4, Name = "Court 4", Type = "Outdoor" },
                new Court { Id = 5, Name = "Court 5", Type = "Outdoor" },
                new Court { Id = 6, Name = "Court 6", Type = "Outdoor" },
                new Court { Id = 7, Name = "Court 7", Type = "Pro Mat" },
                new Court { Id = 8, Name = "Court 8", Type = "Pro Mat" }
            };

            Bookings = new ObservableCollection<Booking>
            {
                new Booking { Id = "BK001", Customer = "Nguyen Van A", Phone = "0901234567", Court = "Court 1", Date = DateTime.Parse("2026-03-13"), Time = "14:00 - 15:00", Type = "Casual", Status = "Checked-in", Amount = 150000 },
                new Booking { Id = "BK002", Customer = "Tran Thi B", Phone = "0912345678", Court = "Court 4", Date = DateTime.Parse("2026-03-13"), Time = "15:00 - 16:30", Type = "Casual", Status = "Pending", Amount = 225000 },
                new Booking { Id = "BK003", Customer = "Le Van C", Phone = "0923456789", Court = "Court 7", Date = DateTime.Parse("2026-03-13"), Time = "16:00 - 17:00", Type = "Fixed", Status = "Checked-in", Amount = 200000 },
                new Booking { Id = "BK004", Customer = "Pham Thi D", Phone = "0934567890", Court = "Court 2", Date = DateTime.Parse("2026-03-14"), Time = "09:00 - 10:00", Type = "Casual", Status = "Pending", Amount = 150000 },
                new Booking { Id = "BK005", Customer = "Hoang Van E", Phone = "0945678901", Court = "Court 5", Date = DateTime.Parse("2026-03-14"), Time = "17:00 - 18:30", Type = "Fixed", Status = "Pending", Amount = 225000 }
            };
        }
    }
}
