using System;
using System.Collections.ObjectModel;
using QLSANCL.BadmintonManagement.Models;

namespace QLSANCL.BadmintonManagement.ViewModels
{
    public class CustomersViewModel : BaseViewModel
    {
        public ObservableCollection<Customer> Customers { get; set; }

        private string _searchText;
        public string SearchText
        {
            get => _searchText;
            set => SetProperty(ref _searchText, value);
        }

        public CustomersViewModel()
        {
            LoadData();
        }

        private void LoadData()
        {
            Customers = new ObservableCollection<Customer>
            {
                new Customer { Id = "KH001", Name = "Nguyen Van A", Phone = "0901234567", Email = "nguyenvana@email.com", TotalBookings = 45, TotalSpent = 6750000, MemberSince = DateTime.Parse("2025-01-15"), Status = "VIP" },
                new Customer { Id = "KH002", Name = "Tran Thi B", Phone = "0912345678", Email = "tranthib@email.com", TotalBookings = 28, TotalSpent = 4200000, MemberSince = DateTime.Parse("2025-03-10"), Status = "Regular" },
                new Customer { Id = "KH003", Name = "Le Van C", Phone = "0923456789", Email = "levanc@email.com", TotalBookings = 62, TotalSpent = 9300000, MemberSince = DateTime.Parse("2024-11-20"), Status = "VIP" },
                new Customer { Id = "KH004", Name = "Pham Thi D", Phone = "0934567890", Email = "phamthid@email.com", TotalBookings = 15, TotalSpent = 2250000, MemberSince = DateTime.Parse("2025-05-08"), Status = "Regular" },
                new Customer { Id = "KH005", Name = "Hoang Van E", Phone = "0945678901", Email = "hoangvane@email.com", TotalBookings = 8, TotalSpent = 1200000, MemberSince = DateTime.Parse("2025-08-12"), Status = "New" }
            };
        }
    }
}
