using System.Collections.ObjectModel;
using QLSANCL.BadmintonManagement.Models;

namespace QLSANCL.BadmintonManagement.ViewModels
{
    public class DashboardViewModel : BaseViewModel
    {
        public ObservableCollection<Court> Courts { get; set; }
        public ObservableCollection<Booking> RecentBookings { get; set; }

        private decimal _dailyRevenue;
        public decimal DailyRevenue
        {
            get => _dailyRevenue;
            set => SetProperty(ref _dailyRevenue, value);
        }

        private int _activeBookings;
        public int ActiveBookings
        {
            get => _activeBookings;
            set => SetProperty(ref _activeBookings, value);
        }

        private int _totalCustomers;
        public int TotalCustomers
        {
            get => _totalCustomers;
            set => SetProperty(ref _totalCustomers, value);
        }

        private decimal _monthlyGrowth;
        public decimal MonthlyGrowth
        {
            get => _monthlyGrowth;
            set => SetProperty(ref _monthlyGrowth, value);
        }

        public DashboardViewModel()
        {
            LoadData();
        }

        private void LoadData()
        {
            // Sample data
            Courts = new ObservableCollection<Court>
            {
                new Court { Id = 1, Name = "Court 1", Type = "Indoor", Status = "Available" },
                new Court { Id = 2, Name = "Court 2", Type = "Indoor", Status = "In-use" },
                new Court { Id = 3, Name = "Court 3", Type = "Indoor", Status = "Available" },
                new Court { Id = 4, Name = "Court 4", Type = "Outdoor", Status = "In-use" },
                new Court { Id = 5, Name = "Court 5", Type = "Outdoor", Status = "Available" },
                new Court { Id = 6, Name = "Court 6", Type = "Outdoor", Status = "Maintenance" },
                new Court { Id = 7, Name = "Court 7", Type = "Pro Mat", Status = "In-use" },
                new Court { Id = 8, Name = "Court 8", Type = "Pro Mat", Status = "Available" }
            };

            RecentBookings = new ObservableCollection<Booking>
            {
                new Booking { Id = "BK001", Customer = "Nguyen Van A", Court = "Court 1", Time = "14:00 - 15:00", Status = "Checked-in" },
                new Booking { Id = "BK002", Customer = "Tran Thi B", Court = "Court 4", Time = "15:00 - 16:30", Status = "Pending" },
                new Booking { Id = "BK003", Customer = "Le Van C", Court = "Court 7", Time = "16:00 - 17:00", Status = "Checked-in" },
                new Booking { Id = "BK004", Customer = "Pham Thi D", Court = "Court 2", Time = "17:00 - 18:00", Status = "Pending" }
            };

            DailyRevenue = 2450000;
            ActiveBookings = 18;
            TotalCustomers = 247;
            MonthlyGrowth = 23;
        }
    }
}
