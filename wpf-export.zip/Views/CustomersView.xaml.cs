using System.Windows.Controls;
using QLSANCL.BadmintonManagement.ViewModels;

namespace QLSANCL.BadmintonManagement.Views
{
    public partial class CustomersView : Page
    {
        public CustomersView()
        {
            InitializeComponent();
            DataContext = new CustomersViewModel();
        }
    }
}
