using System.Windows.Controls;
using QLSANCL.BadmintonManagement.ViewModels;

namespace QLSANCL.BadmintonManagement.Views
{
    public partial class DashboardView : Page
    {
        public DashboardView()
        {
            InitializeComponent();
            DataContext = new DashboardViewModel();
        }
    }
}
