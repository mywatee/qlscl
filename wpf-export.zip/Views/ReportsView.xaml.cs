using System.Windows.Controls;

namespace QLSANCL.BadmintonManagement.Views
{
    public partial class ReportsView : Page
    {
        public ReportsView()
        {
            InitializeComponent();
        }
    }
}
