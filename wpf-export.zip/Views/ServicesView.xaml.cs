using System.Windows.Controls;

namespace QLSANCL.BadmintonManagement.Views
{
    public partial class ServicesView : Page
    {
        public ServicesView()
        {
            InitializeComponent();
        }
    }
}
