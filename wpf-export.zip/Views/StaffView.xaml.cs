using System.Windows.Controls;

namespace QLSANCL.BadmintonManagement.Views
{
    public partial class StaffView : Page
    {
        public StaffView()
        {
            InitializeComponent();
        }
    }
}
